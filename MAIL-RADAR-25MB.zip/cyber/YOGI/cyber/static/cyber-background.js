/**
 * MAILRADAR // CYBER SECURITY ANIMATED BACKGROUND & AUDIO ENGINE
 * High-performance 60fps HTML5 Canvas Engine
 * Modes: Neural Constellation Mesh, Digital Matrix Stream, Tactical 3D Grid
 * Web Audio API Tactical Sound Synthesizer (Zero External Dependencies)
 */

(function () {
  "use strict";

  // =========================================================================
  // Web Audio Tactical Sound Synthesizer
  // =========================================================================
  class CyberSoundEngine {
    constructor() {
      this.ctx = null;
      this.enabled = localStorage.getItem("mailradar_sfx") !== "false";
      this.initOnUserGesture();
    }

    initOnUserGesture() {
      const unlock = () => {
        if (!this.ctx) {
          const AudioContext = window.AudioContext || window.webkitAudioContext;
          if (AudioContext) {
            this.ctx = new AudioContext();
          }
        }
        if (this.ctx && this.ctx.state === "suspended") {
          this.ctx.resume();
        }
        window.removeEventListener("click", unlock);
        window.removeEventListener("keydown", unlock);
      };
      window.addEventListener("click", unlock, { once: true });
      window.addEventListener("keydown", unlock, { once: true });
    }

    toggle() {
      this.enabled = !this.enabled;
      localStorage.setItem("mailradar_sfx", this.enabled ? "true" : "false");
      if (this.enabled) {
        this.playBlip(880, 0.05);
      }
      return this.enabled;
    }

    playBlip(freq = 980, duration = 0.06, type = "sine") {
      if (!this.enabled || !this.ctx) return;
      try {
        const osc = this.ctx.createOscillator();
        const gain = this.ctx.createGain();
        osc.type = type;
        osc.frequency.setValueAtTime(freq, this.ctx.currentTime);
        osc.frequency.exponentialRampToValueAtTime(freq * 1.5, this.ctx.currentTime + duration);

        gain.gain.setValueAtTime(0.04, this.ctx.currentTime);
        gain.gain.exponentialRampToValueAtTime(0.0001, this.ctx.currentTime + duration);

        osc.connect(gain);
        gain.connect(this.ctx.destination);

        osc.start();
        osc.stop(this.ctx.currentTime + duration);
      } catch (e) {
        // Ignore audio context errors
      }
    }

    playSweep() {
      if (!this.enabled || !this.ctx) return;
      try {
        const osc = this.ctx.createOscillator();
        const gain = this.ctx.createGain();
        osc.type = "sawtooth";
        osc.frequency.setValueAtTime(180, this.ctx.currentTime);
        osc.frequency.exponentialRampToValueAtTime(900, this.ctx.currentTime + 0.28);

        gain.gain.setValueAtTime(0.03, this.ctx.currentTime);
        gain.gain.exponentialRampToValueAtTime(0.0001, this.ctx.currentTime + 0.28);

        const filter = this.ctx.createBiquadFilter();
        filter.type = "lowpass";
        filter.frequency.setValueAtTime(600, this.ctx.currentTime);
        filter.frequency.exponentialRampToValueAtTime(2400, this.ctx.currentTime + 0.28);

        osc.connect(filter);
        filter.connect(gain);
        gain.connect(this.ctx.destination);

        osc.start();
        osc.stop(this.ctx.currentTime + 0.28);
      } catch (e) {}
    }

    playLock() {
      if (!this.enabled || !this.ctx) return;
      try {
        const t = this.ctx.currentTime;
        [587.33, 880, 1174.66].forEach((f, idx) => {
          const osc = this.ctx.createOscillator();
          const gain = this.ctx.createGain();
          osc.type = "sine";
          osc.frequency.setValueAtTime(f, t + idx * 0.06);

          gain.gain.setValueAtTime(0.05, t + idx * 0.06);
          gain.gain.exponentialRampToValueAtTime(0.0001, t + idx * 0.06 + 0.15);

          osc.connect(gain);
          gain.connect(this.ctx.destination);

          osc.start(t + idx * 0.06);
          osc.stop(t + idx * 0.06 + 0.15);
        });
      } catch (e) {}
    }

    playThreatAlert() {
      if (!this.enabled || !this.ctx) return;
      try {
        const osc = this.ctx.createOscillator();
        const gain = this.ctx.createGain();
        osc.type = "sawtooth";
        osc.frequency.setValueAtTime(440, this.ctx.currentTime);
        osc.frequency.setValueAtTime(320, this.ctx.currentTime + 0.1);

        gain.gain.setValueAtTime(0.06, this.ctx.currentTime);
        gain.gain.exponentialRampToValueAtTime(0.0001, this.ctx.currentTime + 0.25);

        osc.connect(gain);
        gain.connect(this.ctx.destination);

        osc.start();
        osc.stop(this.ctx.currentTime + 0.25);
      } catch (e) {}
    }
  }

  // =========================================================================
  // Canvas Animation Controller
  // =========================================================================
  class CyberBackgroundEngine {
    constructor(canvasId) {
      this.canvas = document.getElementById(canvasId);
      if (!this.canvas) return;
      this.ctx = this.canvas.getContext("2d");
      this.width = window.innerWidth;
      this.height = window.innerHeight;

      // Modes: 'mesh' (Neural constellation), 'matrix' (Digital rain), 'grid' (Tactical 3D grid)
      this.modes = ["mesh", "matrix", "grid"];
      this.currentModeIndex = 0;
      this.mode = localStorage.getItem("mailradar_bg_mode") || "mesh";
      if (!this.modes.includes(this.mode)) this.mode = "mesh";

      this.mouse = { x: -1000, y: -1000, active: false };
      this.nodes = [];
      this.packets = [];
      this.matrixColumns = [];
      this.gridOffset = 0;
      this.radarAngle = 0;

      this.isRunning = true;
      this.lastFrameTime = performance.now();

      this.initCanvas();
      this.initEvents();
      this.setupMode();
      this.animate();
    }

    initCanvas() {
      const dpr = Math.min(window.devicePixelRatio || 1, 2);
      this.width = window.innerWidth;
      this.height = window.innerHeight;
      this.canvas.width = this.width * dpr;
      this.canvas.height = this.height * dpr;
      this.canvas.style.width = `${this.width}px`;
      this.canvas.style.height = `${this.height}px`;
      this.ctx.scale(dpr, dpr);
    }

    initEvents() {
      window.addEventListener("resize", () => {
        this.initCanvas();
        this.setupMode();
      });

      window.addEventListener("mousemove", (e) => {
        this.mouse.x = e.clientX;
        this.mouse.y = e.clientY;
        this.mouse.active = true;
      });

      window.addEventListener("mouseleave", () => {
        this.mouse.active = false;
        this.mouse.x = -1000;
        this.mouse.y = -1000;
      });

      document.addEventListener("visibilitychange", () => {
        this.isRunning = !document.hidden;
        if (this.isRunning) {
          this.lastFrameTime = performance.now();
          this.animate();
        }
      });
    }

    setMode(newMode) {
      if (this.modes.includes(newMode)) {
        this.mode = newMode;
        localStorage.setItem("mailradar_bg_mode", newMode);
        this.setupMode();
      }
    }

    cycleMode() {
      const idx = this.modes.indexOf(this.mode);
      const nextIdx = (idx + 1) % this.modes.length;
      this.setMode(this.modes[nextIdx]);
      return this.mode;
    }

    setupMode() {
      if (this.mode === "mesh") {
        this.setupMesh();
      } else if (this.mode === "matrix") {
        this.setupMatrix();
      } else if (this.mode === "grid") {
        this.setupGrid();
      }
    }

    // -----------------------------------------------------------------------
    // Mode 1: Cyber Mesh / Neural Constellation
    // -----------------------------------------------------------------------
    setupMesh() {
      const count = Math.min(Math.floor((this.width * this.height) / 14000), 100);
      this.nodes = [];
      this.packets = [];

      for (let i = 0; i < count; i++) {
        this.nodes.push({
          x: Math.random() * this.width,
          y: Math.random() * this.height,
          vx: (Math.random() - 0.5) * 0.75,
          vy: (Math.random() - 0.5) * 0.75,
          radius: Math.random() * 2 + 1.2,
          color: Math.random() > 0.4 ? "rgba(37, 232, 74," : "rgba(45, 212, 191,",
          baseAlpha: Math.random() * 0.4 + 0.3,
          isHub: Math.random() > 0.92,
        });
      }
    }

    renderMesh(dt) {
      const ctx = this.ctx;
      const w = this.width;
      const h = this.height;

      ctx.clearRect(0, 0, w, h);

      // Deep dark ambient vignette
      const radGlow = ctx.createRadialGradient(w / 2, h * 0.35, 100, w / 2, h * 0.35, Math.max(w, h));
      radGlow.addColorStop(0, "rgba(10, 24, 18, 0.45)");
      radGlow.addColorStop(0.5, "rgba(7, 14, 11, 0.7)");
      radGlow.addColorStop(1, "rgba(5, 8, 7, 0.95)");
      ctx.fillStyle = radGlow;
      ctx.fillRect(0, 0, w, h);

      // Draw faint cyber grid backdrop
      ctx.strokeStyle = "rgba(37, 232, 74, 0.035)";
      ctx.lineWidth = 1;
      const gridSize = 64;
      ctx.beginPath();
      for (let x = 0; x < w; x += gridSize) {
        ctx.moveTo(x, 0);
        ctx.lineTo(x, h);
      }
      for (let y = 0; y < h; y += gridSize) {
        ctx.moveTo(0, y);
        ctx.lineTo(w, y);
      }
      ctx.stroke();

      const maxDist = 135;
      const mouseDist = 160;

      // Update and connect nodes
      for (let i = 0; i < this.nodes.length; i++) {
        const n1 = this.nodes[i];
        n1.x += n1.vx;
        n1.y += n1.vy;

        if (n1.x < 0) n1.x = w;
        else if (n1.x > w) n1.x = 0;
        if (n1.y < 0) n1.y = h;
        else if (n1.y > h) n1.y = 0;

        // Mouse reaction: gentle deflection
        if (this.mouse.active) {
          const dx = n1.x - this.mouse.x;
          const dy = n1.y - this.mouse.y;
          const d = Math.sqrt(dx * dx + dy * dy);
          if (d < mouseDist) {
            const force = (1 - d / mouseDist) * 1.5;
            n1.x += (dx / d) * force;
            n1.y += (dy / d) * force;
          }
        }

        // Draw connections between close nodes
        for (let j = i + 1; j < this.nodes.length; j++) {
          const n2 = this.nodes[j];
          const dx = n1.x - n2.x;
          const dy = n1.y - n2.y;
          const dist = Math.sqrt(dx * dx + dy * dy);

          if (dist < maxDist) {
            const alpha = (1 - dist / maxDist) * 0.22;
            ctx.strokeStyle = `rgba(37, 232, 74, ${alpha})`;
            ctx.lineWidth = 0.9;
            ctx.beginPath();
            ctx.moveTo(n1.x, n1.y);
            ctx.lineTo(n2.x, n2.y);
            ctx.stroke();

            // Chance to spawn data packet traveling between nodes
            if (Math.random() < 0.0003 && this.packets.length < 25) {
              this.packets.push({
                x1: n1.x,
                y1: n1.y,
                x2: n2.x,
                y2: n2.y,
                progress: 0,
                speed: 0.015 + Math.random() * 0.02,
                color: Math.random() > 0.5 ? "#25e84a" : "#00f0ff",
              });
            }
          }
        }

        // Draw node
        ctx.fillStyle = `${n1.color}${n1.baseAlpha})`;
        ctx.beginPath();
        ctx.arc(n1.x, n1.y, n1.radius, 0, Math.PI * 2);
        ctx.fill();

        // Hub nodes get an extra halo ring
        if (n1.isHub) {
          ctx.strokeStyle = "rgba(0, 240, 255, 0.35)";
          ctx.lineWidth = 1;
          ctx.beginPath();
          ctx.arc(n1.x, n1.y, n1.radius + 4, 0, Math.PI * 2);
          ctx.stroke();
        }
      }

      // Update and draw packets
      for (let p = this.packets.length - 1; p >= 0; p--) {
        const pkt = this.packets[p];
        pkt.progress += pkt.speed;
        if (pkt.progress >= 1) {
          this.packets.splice(p, 1);
          continue;
        }
        const px = pkt.x1 + (pkt.x2 - pkt.x1) * pkt.progress;
        const py = pkt.y1 + (pkt.y2 - pkt.y1) * pkt.progress;

        ctx.fillStyle = pkt.color;
        ctx.shadowColor = pkt.color;
        ctx.shadowBlur = 8;
        ctx.beginPath();
        ctx.arc(px, py, 2.2, 0, Math.PI * 2);
        ctx.fill();
        ctx.shadowBlur = 0;
      }

      // Draw subtle interactive crosshair at mouse
      if (this.mouse.active) {
        ctx.strokeStyle = "rgba(45, 212, 191, 0.28)";
        ctx.lineWidth = 1;
        ctx.beginPath();
        ctx.arc(this.mouse.x, this.mouse.y, 22, 0, Math.PI * 2);
        ctx.stroke();

        ctx.beginPath();
        ctx.moveTo(this.mouse.x - 30, this.mouse.y);
        ctx.lineTo(this.mouse.x + 30, this.mouse.y);
        ctx.moveTo(this.mouse.x, this.mouse.y - 30);
        ctx.lineTo(this.mouse.x, this.mouse.y + 30);
        ctx.stroke();
      }
    }

    // -----------------------------------------------------------------------
    // Mode 2: Digital Matrix Rain
    // -----------------------------------------------------------------------
    setupMatrix() {
      const fontSize = 16;
      const columns = Math.floor(this.width / fontSize);
      this.matrixColumns = [];
      const cyberChars = "01010101ABCDEF9876543210><{}/*&^%$#@!;:DNSMXSPFDMARCRFC5322";

      for (let i = 0; i < columns; i++) {
        this.matrixColumns.push({
          x: i * fontSize,
          y: Math.random() * -this.height,
          speed: 1.2 + Math.random() * 2.8,
          chars: cyberChars,
          fontSize: fontSize,
        });
      }
    }

    renderMatrix() {
      const ctx = this.ctx;
      const w = this.width;
      const h = this.height;

      // Dark fade trail
      ctx.fillStyle = "rgba(6, 10, 8, 0.14)";
      ctx.fillRect(0, 0, w, h);

      for (let i = 0; i < this.matrixColumns.length; i++) {
        const col = this.matrixColumns[i];
        col.y += col.speed;
        if (col.y > h && Math.random() > 0.975) {
          col.y = 0;
          col.speed = 1.2 + Math.random() * 2.8;
        }

        const char = col.chars[Math.floor(Math.random() * col.chars.length)];
        ctx.font = `${col.fontSize}px 'JetBrains Mono', monospace`;

        // Head character is glowing white/cyan
        ctx.fillStyle = "#e0fff4";
        ctx.shadowColor = "#25e84a";
        ctx.shadowBlur = 10;
        ctx.fillText(char, col.x, col.y);
        ctx.shadowBlur = 0;

        // Tail character is neon green
        ctx.fillStyle = "rgba(37, 232, 74, 0.4)";
        ctx.fillText(char, col.x, col.y - col.fontSize);
      }
    }

    // -----------------------------------------------------------------------
    // Mode 3: Tactical 3D Cyber Grid
    // -----------------------------------------------------------------------
    setupGrid() {
      this.gridOffset = 0;
    }

    renderGrid() {
      const ctx = this.ctx;
      const w = this.width;
      const h = this.height;

      ctx.clearRect(0, 0, w, h);

      // Deep dark background
      ctx.fillStyle = "#070b09";
      ctx.fillRect(0, 0, w, h);

      const horizon = h * 0.45;
      this.gridOffset = (this.gridOffset + 0.8) % 40;

      // Vertical perspective lines
      ctx.strokeStyle = "rgba(37, 232, 74, 0.15)";
      ctx.lineWidth = 1;
      const fovCenter = w / 2;
      const lineCount = 32;

      for (let i = -lineCount; i <= lineCount; i++) {
        const xBottom = fovCenter + i * 70;
        ctx.beginPath();
        ctx.moveTo(fovCenter, horizon);
        ctx.lineTo(xBottom, h);
        ctx.stroke();
      }

      // Horizontal receding lines
      for (let y = horizon; y < h; y += 8 + (y - horizon) * 0.12) {
        const actualY = y + (this.gridOffset * (y - horizon)) / 200;
        if (actualY > h) continue;
        const alpha = Math.min(0.25, ((actualY - horizon) / (h - horizon)) * 0.3);
        ctx.strokeStyle = `rgba(0, 240, 255, ${alpha})`;
        ctx.beginPath();
        ctx.moveTo(0, actualY);
        ctx.lineTo(w, actualY);
        ctx.stroke();
      }

      // Top cyber sky scanlines
      ctx.fillStyle = "rgba(37, 232, 74, 0.04)";
      for (let y = 0; y < horizon; y += 4) {
        ctx.fillRect(0, y, w, 1);
      }

      // Glowing horizon laser line
      const laserGlow = ctx.createLinearGradient(0, horizon, w, horizon);
      laserGlow.addColorStop(0, "rgba(37, 232, 74, 0)");
      laserGlow.addColorStop(0.5, "rgba(0, 240, 255, 0.85)");
      laserGlow.addColorStop(1, "rgba(37, 232, 74, 0)");
      ctx.strokeStyle = laserGlow;
      ctx.lineWidth = 2;
      ctx.shadowColor = "#00f0ff";
      ctx.shadowBlur = 12;
      ctx.beginPath();
      ctx.moveTo(0, horizon);
      ctx.lineTo(w, horizon);
      ctx.stroke();
      ctx.shadowBlur = 0;
    }

    animate(now = performance.now()) {
      if (!this.isRunning) return;
      const dt = (now - this.lastFrameTime) / 1000;
      this.lastFrameTime = now;

      if (this.mode === "mesh") {
        this.renderMesh(dt);
      } else if (this.mode === "matrix") {
        this.renderMatrix();
      } else if (this.mode === "grid") {
        this.renderGrid();
      }

      requestAnimationFrame((t) => this.animate(t));
    }
  }

  // =========================================================================
  // Initialize and Expose Global Cyber Engines
  // =========================================================================
  window.addEventListener("DOMContentLoaded", () => {
    // Canvas background
    window.CyberBG = new CyberBackgroundEngine("cyberCanvas");
    // Sound FX
    window.CyberSFX = new CyberSoundEngine();

    // Wire Up Top Telemetry Bar Toggles
    const sfxBtn = document.getElementById("sfxToggleBtn");
    if (sfxBtn) {
      const updateSfxUI = (enabled) => {
        sfxBtn.innerHTML = enabled
          ? `<span class="cyber-btn-icon">&#128266;</span> <span>SFX: ON</span>`
          : `<span class="cyber-btn-icon">&#128263;</span> <span>SFX: OFF</span>`;
        sfxBtn.classList.toggle("cyber-toggle-active", enabled);
      };
      updateSfxUI(window.CyberSFX.enabled);

      sfxBtn.addEventListener("click", () => {
        const state = window.CyberSFX.toggle();
        updateSfxUI(state);
      });
    }

    const fxModeBtn = document.getElementById("fxModeBtn");
    if (fxModeBtn) {
      const updateModeUI = (m) => {
        fxModeBtn.innerHTML = `<span class="cyber-btn-icon">&#9881;</span> <span>FX: ${m.toUpperCase()}</span>`;
      };
      updateModeUI(window.CyberBG.mode);

      fxModeBtn.addEventListener("click", () => {
        const nextMode = window.CyberBG.cycleMode();
        updateModeUI(nextMode);
        if (window.CyberSFX) window.CyberSFX.playBlip(1200, 0.05);
      });
    }

    // Attach click audio blip to chips and submit button
    document.querySelectorAll(".sample-chip, .new-search-btn, .bte-submit-btn, .nav-menu-btn").forEach((btn) => {
      btn.addEventListener("click", () => {
        if (window.CyberSFX) window.CyberSFX.playBlip(1040, 0.04);
      });
    });
  });
})();
